// Wait for the full page to load
window.addEventListener('load', function() {
    const loadingScreen = document.getElementById('loading-screen');
    const mainContent = document.getElementById('main-content');
    
    // Ensure a geometric pattern container exists
    let patternContainer = document.querySelector('.geometric-pattern');
    if (!patternContainer) {
      patternContainer = document.createElement('div');
      patternContainer.classList.add('geometric-pattern');
      document.getElementById('loading-screen').appendChild(patternContainer);
    }
    
    // Variables for animation loop
    let startTime = null;
    let animationFrameId;
  
    // Animation loop using requestAnimationFrame to update shape rotations
    function updateAnimations(timestamp) {
      if (!startTime) startTime = timestamp;
      const elapsed = timestamp - startTime;
      
      // Rotate each shape slightly based on elapsed time
      const shapes = document.querySelectorAll('.geometric-pattern .shape');
      shapes.forEach((shape, index) => {
        let angle = (elapsed / 1000 * (10 + index)) % 360;
        shape.style.transform = `rotate(${angle}deg)`;
      });
      
      animationFrameId = requestAnimationFrame(updateAnimations);
    }
    animationFrameId = requestAnimationFrame(updateAnimations);
    
    // Keep the loading screen visible for at least 5 seconds
    setTimeout(() => {
      loadingScreen.classList.add('fade-out');
      cancelAnimationFrame(animationFrameId);
      // After fade-out (1s), hide the loading screen and reveal main content
      setTimeout(() => {
        loadingScreen.style.display = 'none';
        mainContent.style.display = 'block';
      }, 1000);
    }, 10000);
    
    // Function to create a random geometric shape
    function createRandomShape() {
      const shape = document.createElement('div');
      shape.classList.add('shape');
      
      // Randomly choose a shape type
      const types = ['circle', 'square', 'triangle'];
      const chosenType = types[Math.floor(Math.random() * types.length)];
      shape.classList.add(chosenType);
      
      // Randomly assign size
      const sizes = ['small', 'medium', 'large'];
      const chosenSize = sizes[Math.floor(Math.random() * sizes.length)];
      shape.classList.add(chosenSize);
      
      // Randomly assign a color class (only using white, light-green, light-blue, lavender)
      const colors = ['white', 'light-green', 'light-blue', 'lavender'];
      const chosenColor = colors[Math.floor(Math.random() * colors.length)];
      shape.classList.add(chosenColor);
      
      // Random position within the viewport
      shape.style.top = Math.floor(Math.random() * 90) + '%';
      shape.style.left = Math.floor(Math.random() * 90) + '%';
      
      // Randomly add one animation class
      const animations = ['animate-float', 'animate-rotate', 'animate-drift', 'animate-pulsate'];
      const chosenAnim = animations[Math.floor(Math.random() * animations.length)];
      shape.classList.add(chosenAnim);
      
      return shape;
    }
    
    // Dynamically add multiple shapes to the geometric pattern container
    for (let i = 0; i < 20; i++) {
      let newShape = createRandomShape();
      patternContainer.appendChild(newShape);
    }
    
    // Allow user interaction: on click, randomly adjust the animation duration of shapes
    let clickCounter = 0;
    document.addEventListener('click', function() {
      clickCounter++;
      const shapes = document.querySelectorAll('.geometric-pattern .shape');
      shapes.forEach((shape) => {
        let newDuration = Math.random() * 5 + 2; // between 2s and 7s
        shape.style.animationDuration = `${newDuration}s`;
      });
      console.log('User clicked. Animation speeds updated:', clickCounter);
    });
    
    // Periodically log performance metrics
    function logPerformanceMetrics() {
      let now = performance.now();
      console.log(`Performance log: ${now.toFixed(2)}ms elapsed.`);
    }
    let metricsInterval = setInterval(logPerformanceMetrics, 1000);
    
    // Stop logging after 6 seconds
    setTimeout(() => {
      clearInterval(metricsInterval);
    }, 6000);
    
    // Extra placeholder functions to extend JS file length
    function placeholderFunction1() {
      let a = 10, b = 20;
      let c = a + b;
      console.log('Placeholder Function 1:', c);
    }
    
    function placeholderFunction2() {
      let x = 5;
      for (let i = 0; i < 10; i++) {
        x += i;
      }
      console.log('Placeholder Function 2:', x);
    }
    
    function placeholderFunction3() {
      let str = 'Loading animation test';
      let reversed = str.split('').reverse().join('');
      console.log('Placeholder Function 3:', reversed);
    }
    
    placeholderFunction1();
    placeholderFunction2();
    placeholderFunction3();
    
    // Additional loops and functions to ensure file length exceeds 100 lines
    let counter = 0;
    while (counter < 20) {
      console.log('Counter:', counter);
      counter++;
    }
    
    function extraFunction1(param) {
      return param * 2;
    }
    
    function extraFunction2(param) {
      return param * 3;
    }
    
    function extraFunction3(param) {
      return param * 4;
    }
    
    console.log(extraFunction1(5), extraFunction2(5), extraFunction3(5));
    
    for (let i = 0; i < 10; i++) {
      console.log('Loop iteration:', i);
    }
    
    function finalPlaceholder() {
      let sum = 0;
      for (let i = 1; i <= 10; i++) {
        sum += i;
      }
      console.log('Final placeholder sum:', sum);
    }
    finalPlaceholder();
  });
  