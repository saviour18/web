document.addEventListener("DOMContentLoaded", function() {
    const menuToggle = document.querySelector('.menu-toggle');
    const sideNav = document.querySelector('.side-nav');
    const closeBtn = document.querySelector('.side-nav .close-btn');
    const sideNavLinks = document.querySelectorAll('.side-nav a');
  
    // Function to toggle side navigation pane
    function toggleSideNav() {
      sideNav.classList.toggle('active');
    }
  
    // Event listener for menu toggle icon
    menuToggle.addEventListener('click', function(e) {
      toggleSideNav();
      animateMenuIcon();
      e.stopPropagation();
    });
  
    // Event listener for close button on side nav
    if (closeBtn) {
      closeBtn.addEventListener('click', function(e) {
        toggleSideNav();
        e.stopPropagation();
      });
    }
  
    // Close side nav when a link is clicked
    sideNavLinks.forEach(link => {
      link.addEventListener('click', function() {
        sideNav.classList.remove('active');
      });
    });
  
    // Close side nav if user clicks outside of it
    document.addEventListener('click', function(e) {
      if (sideNav.classList.contains('active')) {
        if (!sideNav.contains(e.target) && !menuToggle.contains(e.target)) {
          sideNav.classList.remove('active');
        }
      }
    });
  
    // Ensure side nav is closed on window resize if above mobile breakpoint
    window.addEventListener('resize', function() {
      if (window.innerWidth > 768) {
        sideNav.classList.remove('active');
      }
    });
  
    // Animate the menu icon when clicked
    function animateMenuIcon() {
      menuToggle.classList.add('clicked');
      setTimeout(() => {
        menuToggle.classList.remove('clicked');
      }, 300);
    }
  
    // Initialize nav link animations with staggered transition delays
    function initLinkAnimations() {
      sideNavLinks.forEach((link, index) => {
        link.style.transition = `opacity 0.5s ease ${index * 0.1}s, transform 0.5s ease ${index * 0.1}s`;
      });
    }
    initLinkAnimations();
  
    // Extra placeholder functions to extend JS file length and simulate modeling
    function placeholderFunction1() {
      let a = 10, b = 20;
      console.log('Placeholder Function 1:', a + b);
    }
  
    function placeholderFunction2() {
      let x = 5;
      for (let i = 0; i < 10; i++) {
        x += i;
      }
      console.log('Placeholder Function 2:', x);
    }
  
    function placeholderFunction3() {
      let str = 'DF STUDIOS Navigation';
      let reversed = str.split('').reverse().join('');
      console.log('Placeholder Function 3:', reversed);
    }
  
    placeholderFunction1();
    placeholderFunction2();
    placeholderFunction3();
  
    // Simulate a repeating animation effect on nav links
    let repeatCount = 0;
    function repeatNavAnimation() {
      repeatCount++;
      sideNavLinks.forEach((link, index) => {
        // Toggle a slight translate effect for demonstration
        link.style.transform = `translateX(${(repeatCount % 2 === 0) ? '0px' : '5px'})`;
      });
      if (repeatCount < 50) {
        requestAnimationFrame(repeatNavAnimation);
      }
    }
    requestAnimationFrame(repeatNavAnimation);
  
    // More extra functions to ensure extended functionality
    function extraCalculation() {
      let sum = 0;
      for (let i = 1; i <= 100; i++) {
        sum += i;
      }
      console.log('Extra Calculation Sum:', sum);
    }
    extraCalculation();
  
    function logStatus() {
      console.log('Navigation module loaded. Current window width:', window.innerWidth);
    }
    logStatus();
  
    // Final placeholder log to mark end of nav script
    console.log('DF STUDIOS Navigation JS module initialized successfully.');
  });
  