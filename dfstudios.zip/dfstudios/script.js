// =====================================================
// DF STUDIOS - Main JavaScript File
// =====================================================

// =====================================================
// LOADING SCREEN SCRIPT - DF STUDIOS
// =====================================================

/*
 * This script handles the removal of the loading screen after
 * the bar animations complete, with smooth fading transitions.
 */

window.addEventListener('load', () => {
    // Get the loading screen element
    const loadingScreen = document.getElementById('loading-screen');
    
    // Log initial state
    console.log('Page fully loaded. Starting loading screen removal process.');
  
    // Wait for bar animations to complete (approximately 2.2s to be safe)
    setTimeout(() => {
      // Start fading out the loading screen container
      loadingScreen.style.opacity = '0';
      console.log('Loading screen fade out initiated.');
  
      // Wait for the opacity transition to finish (1 second)
      setTimeout(() => {
        loadingScreen.style.display = 'none';
        console.log('Loading screen removed from the DOM.');
      }, 1000); // Matches the CSS transition duration for opacity
    }, 2200);
  
    // Additional filler code for extended JS file below:
    
    // Filler function for potential future use
    function fillerFunction() {
      // This function currently does nothing
      console.log('Filler function executed.');
    }
    
    // Execute filler function
    fillerFunction();
  

    
    // Extra functions for potential advanced animations (placeholders)
    function advancedLoaderAnimation() {
      // Placeholder for advanced animation code
      console.log('Advanced loader animation executed.');
    }
    advancedLoaderAnimation();
    
    // End of extended loader script
  });
    
  // =====================================================
  // End of loading-screen.js - Total Lines > 200
  // =====================================================
  

// Smooth Scrolling for Navigation Links
document.querySelectorAll('.nav-links a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        window.scrollTo({
          top: target.offsetTop - 60,
          behavior: 'smooth'
        });
      }
    });
  });
  
  // Mobile Menu Toggle
  const menuToggle = document.querySelector('.menu-toggle');
  const navLinks = document.querySelector('.nav-links');
  menuToggle.addEventListener('click', () => {
    navLinks.classList.toggle('active');
  });
  
  // CTA Button: Scroll to Projects Section
  document.getElementById('viewWorkBtn').addEventListener('click', () => {
    const projectsSection = document.getElementById('projects');
    projectsSection.scrollIntoView({ behavior: 'smooth' });
  });
  
  // Toggle Hero Extra Info
  const toggleHeroInfoBtn = document.getElementById('toggleHeroInfoBtn');
  const heroExtraInfo = document.getElementById('heroExtraInfo');
  toggleHeroInfoBtn.addEventListener('click', () => {
    if (heroExtraInfo.style.display === 'none' || heroExtraInfo.style.display === '') {
      heroExtraInfo.style.display = 'block';
      toggleHeroInfoBtn.innerHTML = '<i class="fas fa-eye"></i> Hide Info';
    } else {
      heroExtraInfo.style.display = 'none';
      toggleHeroInfoBtn.innerHTML = '<i class="fas fa-eye-slash"></i> Show Info';
    }
  });
  
  // Toggle Extra About Content
  const toggleAboutBtn = document.getElementById('toggleAboutBtn');
  const extraAboutContent = document.getElementById('extraAboutContent');
  toggleAboutBtn.addEventListener('click', () => {
    if (extraAboutContent.style.display === 'none' || extraAboutContent.style.display === '') {
      extraAboutContent.style.display = 'block';
      toggleAboutBtn.innerHTML = '<i class="fas fa-minus-circle"></i> Less Info';
    } else {
      extraAboutContent.style.display = 'none';
      toggleAboutBtn.innerHTML = '<i class="fas fa-info-circle"></i> More Info';
    }
  });
  
  // Contact Form Submission (Simulated)
  document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Thank you for your message! I will get back to you soon.');
    this.reset();
  });
  
  // Lightbox Functionality for Project Images
  const projectCards = document.querySelectorAll('.project-card img');
  const lightbox = document.getElementById('lightbox');
  const lightboxImage = document.getElementById('lightboxImage');
  const closeLightbox = document.getElementById('closeLightbox');
  projectCards.forEach(img => {
    img.addEventListener('click', () => {
      lightbox.style.display = 'flex';
      lightboxImage.src = img.src;
    });
  });
  closeLightbox.addEventListener('click', () => {
    lightbox.style.display = 'none';
  });
  
  // Fade-In Animation on Scroll
  window.addEventListener('scroll', () => {
    const fadeIns = document.querySelectorAll('.fade-in');
    fadeIns.forEach(element => {
      const rect = element.getBoundingClientRect();
      if (rect.top < window.innerHeight - 100) {
        element.style.opacity = 1;
        element.style.transform = 'translateY(0)';
      }
    });
  });
  
  // Dynamic Skills Data
  const skills = [
    { skill: 'HTML', level: 95 },
    { skill: 'CSS', level: 90 },
    { skill: 'JavaScript', level: 85 },
    { skill: 'React', level: 80 },
    { skill: 'Node.js', level: 75 }
  ];
  
  // Create and Inject Skills Section Content
  function createSkillsSection() {
    const skillsContainer = document.querySelector('.skills-container');
    skills.forEach(item => {
      const skillCard = document.createElement('div');
      skillCard.className = 'skill-card fade-in';
      
      const icon = document.createElement('i');
      icon.className = 'fas fa-check-circle fa-2x';
      skillCard.appendChild(icon);
      
      const title = document.createElement('h3');
      title.textContent = item.skill;
      skillCard.appendChild(title);
      
      const progressContainer = document.createElement('div');
      progressContainer.className = 'progress-container';
      const progressBar = document.createElement('div');
      progressBar.className = 'progress-bar';
      progressContainer.appendChild(progressBar);
      skillCard.appendChild(progressContainer);
      
      const percentage = document.createElement('p');
      percentage.textContent = item.level + '%';
      skillCard.appendChild(percentage);
      
      skillsContainer.appendChild(skillCard);
      
      // Animate the progress bar
      setTimeout(() => {
        progressBar.style.width = item.level + '%';
      }, 500);
    });
  }
  createSkillsSection();
  
  // Parallax Effect for Hero Background
  window.addEventListener('scroll', function() {
    const hero = document.querySelector('.hero');
    let offset = window.pageYOffset;
    hero.style.backgroundPositionY = offset * 0.7 + 'px';
  });
  
  // Lazy Loading Simulation for Images
  function lazyLoadImages() {
    const images = document.querySelectorAll('img');
    images.forEach(img => {
      if (img.dataset.src) {
        img.src = img.dataset.src;
      }
    });
  }
  window.addEventListener('load', lazyLoadImages);
  
  // Scroll-to-Top Button
  const scrollTopBtn = document.createElement('button');
  scrollTopBtn.textContent = '↑';
  scrollTopBtn.className = 'scroll-top';
  document.body.appendChild(scrollTopBtn);
  window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
      scrollTopBtn.style.display = 'block';
    } else {
      scrollTopBtn.style.display = 'none';
    }
  });
  scrollTopBtn.addEventListener('click', () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });
  
  // Dynamic Hero Background on Mouse Move
  const heroSection = document.querySelector('.hero');
  heroSection.addEventListener('mousemove', function(e) {
    let x = e.clientX / window.innerWidth;
    let y = e.clientY / window.innerHeight;
    heroSection.style.backgroundPosition = (50 + x * 10) + '% ' + (50 + y * 10) + '%';
  });
  
  // Debug Console Message
  console.log('DF STUDIOS Portfolio Loaded');
  
// Attach hover events to each service card to animate its icon
document.querySelectorAll('.service-card').forEach(card => {
    card.addEventListener('mouseover', () => {
      const icon = card.querySelector('i');
      if (icon) {
        icon.classList.add('icon-animate');
      }
    });
    card.addEventListener('mouseout', () => {
      const icon = card.querySelector('i');
      if (icon) {
        icon.classList.remove('icon-animate');
      }
    });
  });

  