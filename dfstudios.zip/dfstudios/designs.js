document.addEventListener("DOMContentLoaded", function() {
    // Data mapping for each category (using placeholder images)
    const imageData = {
      posters: [
        "images/posters/mary.png",
        "images/posters/rok.png",
        "images/posters/mary.png",
        "images/posters/rok.png"
      ],
      banners: [
        "images/banners/buyfromme.png",
        "images/banners/eye music.png",
        "images/banners/omni white.png",
        "images/banners/template greenpark.png",
        "images/banners/careparent-banner.png"
      ],
      businessCards: [
        "images/posters/mary.png",
        "images/posters/rok.png",
        "images/posters/mary.png",
        "images/posters/rok.png"
      ],
      envelopes: [
        "images/posters/mary.png",
        "images/posters/rok.png",
        "images/posters/mary.png",
        "images/posters/rok.png"
      ],
      logos: [
        "images/posters/mary.png",
        "images/posters/rok.png",
        "images/posters/mary.png",
        "images/posters/rok.png"
      ],
      others: [
        "images/posters/mary.png",
        "images/posters/rok.png",
        "images/posters/mary.png",
        "images/posters/rok.png"
      ]
    };
  
    let currentCategory = "posters";
    let currentIndex = 0;
    let zoomLevel = 1;
  
    const carousel = document.querySelector(".carousel");
    const categoryButtons = document.querySelectorAll(".category-btn");
    const prevBtn = document.getElementById("prevBtn");
    const nextBtn = document.getElementById("nextBtn");
    const lightbox = document.getElementById("lightbox");
    const lightboxImg = document.getElementById("lightbox-img");
    const closeLightbox = document.querySelector(".close-lightbox");
    const zoomInBtn = document.getElementById("zoomIn");
    const zoomOutBtn = document.getElementById("zoomOut");
  
    // Load images into carousel for the given category
    function loadCarousel(category) {
      carousel.innerHTML = "";
      const images = imageData[category];
      images.forEach((src, index) => {
        const item = document.createElement("div");
        item.classList.add("carousel-item");
        const img = document.createElement("img");
        img.src = src;
        // Disable right-click on the image
        img.addEventListener("contextmenu", function(e) {
          e.preventDefault();
        });
        // Open lightbox on click
        img.addEventListener("click", function() {
          openLightbox(src);
        });
        item.appendChild(img);
        carousel.appendChild(item);
      });
      currentIndex = 0;
      updateCarousel();
    }
  
    // Update carousel position
    function updateCarousel() {
      const offset = -currentIndex * carousel.clientWidth;
      carousel.style.transform = `translateX(${offset}px)`;
    }
  
    // Navigate to previous image
    function showPrev() {
      if (currentIndex > 0) {
        currentIndex--;
      } else {
        currentIndex = imageData[currentCategory].length - 1;
      }
      updateCarousel();
    }
  
    // Navigate to next image
    function showNext() {
      if (currentIndex < imageData[currentCategory].length - 1) {
        currentIndex++;
      } else {
        currentIndex = 0;
      }
      updateCarousel();
    }
  
    prevBtn.addEventListener("click", showPrev);
    nextBtn.addEventListener("click", showNext);
  
    // Category button click event
    categoryButtons.forEach(btn => {
      btn.addEventListener("click", function() {
        categoryButtons.forEach(b => b.classList.remove("active"));
        this.classList.add("active");
        currentCategory = this.getAttribute("data-category");
        loadCarousel(currentCategory);
      });
    });
  
    // Lightbox functions
    function openLightbox(src) {
      lightbox.style.display = "flex";
      lightboxImg.src = src;
      zoomLevel = 1;
      lightboxImg.style.transform = `scale(${zoomLevel})`;
    }
  
    function closeLightboxFunc() {
      lightbox.style.display = "none";
    }
  
    closeLightbox.addEventListener("click", closeLightboxFunc);
  
    // Zoom in/out functionality
    zoomInBtn.addEventListener("click", function() {
      zoomLevel += 0.2;
      lightboxImg.style.transform = `scale(${zoomLevel})`;
    });
  
    zoomOutBtn.addEventListener("click", function() {
      if (zoomLevel > 0.4) {
        zoomLevel -= 0.2;
        lightboxImg.style.transform = `scale(${zoomLevel})`;
      }
    });
  
    // Prevent drag and right-click on lightbox image
    lightboxImg.addEventListener("dragstart", function(e) {
      e.preventDefault();
    });
    lightboxImg.addEventListener("contextmenu", function(e) {
      e.preventDefault();
    });
  
    // Close lightbox when clicking outside the image area
    lightbox.addEventListener("click", function(e) {
      if (e.target === lightbox) {
        closeLightboxFunc();
      }
    });
  
    // Keyboard event to close lightbox with Escape key
    document.addEventListener("keydown", function(e) {
      if (e.key === "Escape" && lightbox.style.display === "flex") {
        closeLightboxFunc();
      }
    });
  
    // Initialize carousel with default category
    loadCarousel(currentCategory);
  
    // Update carousel on window resize
    window.addEventListener("resize", updateCarousel);
  
    // Placeholder functions to extend file length
    function placeholderFunc1() {
      console.log("Placeholder function 1 executed.");
    }
    function placeholderFunc2() {
      for (let i = 0; i < 5; i++) {
        console.log("Loop iteration:", i);
      }
    }
    function placeholderFunc3() {
      let x = 10;
      x *= 2;
      console.log("Placeholder function 3:", x);
    }
    placeholderFunc1();
    placeholderFunc2();
    placeholderFunc3();
  
    // Extra logging to extend JS file length
    console.log("Designs carousel module initialized.");
    for (let j = 0; j < 10; j++) {
      console.log("Extra log", j);
    }
    console.log("DF STUDIOS carousel script loaded successfully.");
  });
  